//
//  PreviewDrawingView.swift
//  PolyDraw
//
//  Created by Assaf, Michael on 2017-05-24.
//  Copyright © 2017 Chris Chadillon. All rights reserved.
//

import UIKit

class PreviewDrawingView: UIView {

    var theOptionsViewController:OptionsViewController!
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
     
        let theOptions = self.theOptionsViewController.theCurrentOptions
    
        let possibleContext = UIGraphicsGetCurrentContext()
        
        if let theContext = possibleContext {
            theContext.setLineWidth(theOptions.lineWidth)
            let colorSpace = CGColorSpaceCreateDeviceRGB()
            let strokeComponents:[CGFloat] = [theOptions.lineColor.red,theOptions.lineColor.green,theOptions.lineColor.blue,theOptions.lineColor.alpha]
            let strokeColor = CGColor(colorSpace: colorSpace, components: strokeComponents)
            let rect = CGRect(x: 10, y: 10, width: self.frame.size.width - 20, height: self.frame.size.height - 20)
            
            let fillComponents:[CGFloat] = [theOptions.fillColor.red,theOptions.fillColor.green,theOptions.fillColor.blue,theOptions.fillColor.alpha]
            let fillColor = CGColor(colorSpace: colorSpace, components: fillComponents)
            
            theContext.setStrokeColor(strokeColor!)
            theContext.setFillColor(fillColor!)
            
            theContext.addRect(rect)
            theContext.fillPath()

            theContext.addRect(rect)
            theContext.strokePath()
        }
    }
 

}
