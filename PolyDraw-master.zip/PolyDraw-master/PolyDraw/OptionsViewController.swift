//
//  OptionsViewController.swift
//  PolyDraw
//
//  Created by Assaf, Michael on 2017-05-24.
//  Copyright © 2017 Chris Chadillon. All rights reserved.
//

import UIKit

class OptionsViewController: UIViewController {
    
    var theCurrentOptions = Options()
    
    @IBOutlet weak var lineWidth: UISlider!
    @IBOutlet weak var lineColor: UISegmentedControl!
    @IBOutlet weak var filled: UISwitch!
    @IBOutlet weak var fillColor: UISegmentedControl!
    @IBOutlet weak var thePreviewDrawing: PreviewDrawingView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.theCurrentOptions = Options(theLineWidth: CGFloat(self.lineWidth.value), theLineColor: self.lineColor.titleForSegment(at: self.lineColor.selectedSegmentIndex)!, filled: self.filled.isOn, theFillColor: self.fillColor.titleForSegment(at: self.lineColor.selectedSegmentIndex)!)
        self.thePreviewDrawing.theOptionsViewController = self
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func lineWidthChanged(_ sender: UISlider) {
        self.theCurrentOptions.lineWidth = CGFloat(self.lineWidth.value)
        self.thePreviewDrawing.setNeedsDisplay()
    }

    @IBAction func lineColorChanged(_ sender: UISegmentedControl) {
        self.theCurrentOptions.lineColorName = self.lineColor.titleForSegment(at: self.lineColor.selectedSegmentIndex)!
        self.theCurrentOptions.setLineColor(theLineColor: self.theCurrentOptions.lineColorName)
        self.thePreviewDrawing.setNeedsDisplay()
    }
    
    @IBAction func fillChanged(_ sender: UISwitch) {
        self.theCurrentOptions.filled = self.filled.isOn
        self.thePreviewDrawing.setNeedsDisplay()
    }
    
    @IBAction func fillColorChanged(_ sender: UISegmentedControl) {
        self.theCurrentOptions.fillColorName = self.fillColor.titleForSegment(at: self.fillColor.selectedSegmentIndex)!
        self.theCurrentOptions.setFillColor(theFillColor: self.theCurrentOptions.fillColorName)
        self.thePreviewDrawing.setNeedsDisplay()
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
