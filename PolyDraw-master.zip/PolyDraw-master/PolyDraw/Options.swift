//
//  Options.swift
//  PolyDraw
//
//  Created by Assaf, Michael on 2017-05-24.
//  Copyright © 2017 Chris Chadillon. All rights reserved.
//

import Foundation
import UIKit

class Options {
    
    var lineWidth:CGFloat
    var lineColor:CIColor
    var lineColorName:String
    var filled:Bool
    var fillColor:CIColor
    var fillColorName:String
    
    init(theLineWidth:CGFloat = 10, theLineColor:String="Red", filled:Bool=false, theFillColor:String="Green") {
        self.lineWidth = theLineWidth
        self.lineColorName = theLineColor
        self.lineColor = CIColor.red()
        self.filled = filled
        self.fillColorName = theFillColor
        self.fillColor = CIColor.blue()
    }
    
    func setLineColor(theLineColor:String) {
        switch (theLineColor) {
        case "Green":
            self.lineColor = CIColor.green()
            break
        case "Blue":
            self.lineColor = CIColor.blue()
            break
        case "Yellow":
            self.lineColor = CIColor.yellow()
            break
        case "Pink":
            self.lineColor = CIColor.gray()
            break
        case "Black":
            self.lineColor = CIColor.black()
            break
        default:
            self.lineColor = CIColor.red()
            break
        }

    }
    
    func setFillColor(theFillColor:String) {
        switch (theFillColor) {
        case "Green":
            self.fillColor = CIColor.green()
            break
        case "Blue":
            self.fillColor = CIColor.blue()
            break
        case "Yellow":
            self.fillColor = CIColor.yellow()
            break
        case "Pink":
            self.fillColor = CIColor.gray()
            break
        case "Black":
            self.fillColor = CIColor.black()
            break
        default:
            self.fillColor = CIColor.red()
            break
        }
        
    }
}
