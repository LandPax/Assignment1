//
//  Line.swift
//  PolyDraw
//
//  Created by Dirty Landlubber on 2017-05-04.
//  Copyright © 2017 Chris Chadillon. All rights reserved.
//

import UIKit

class Line:Shape {
    
    var fromX:Double
    var fromY:Double
    var toX:Double
    var toY:Double
    
    init(fromX:Double, fromY:Double, toX:Double, toY:Double) {
        self.fromX = fromX
        self.fromY = fromY
        self.toX = toX
        self.toY = toY
        super.init(X: fromX, Y: fromY)
    }
    
    override func draw(_ theContext: CGContext) {
        let fromPoint = CGPoint(x: self.fromX, y: self.fromY)
        let toPoint = CGPoint(x: self.toX, y: self.toY)
        theContext.move(to: fromPoint)
        theContext.addLine(to: toPoint)
        theContext.setLineCap(CGLineCap.round)
    }
}
