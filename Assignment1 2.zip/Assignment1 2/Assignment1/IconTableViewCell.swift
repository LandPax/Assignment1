//
//  IconTableViewCell.swift
//  Assignment1
//
//  Created by Assaf, Michael on 2017-02-24.
//  Copyright © 2017 Assaf, Michael. All rights reserved.
//

import UIKit

class IconTableViewCell: UITableViewCell {
    @IBOutlet weak var theName: UILabel!
    @IBOutlet weak var thePhoneNumber: UILabel!
    @IBOutlet weak var theAvatar: UIImageView!
}
