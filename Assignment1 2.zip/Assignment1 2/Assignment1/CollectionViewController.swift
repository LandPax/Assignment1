//
//  CollectionViewController.swift
//  Assignment1
//
//  Created by Dirty Landlubber on 2017-02-16.
//  Copyright © 2017 Assaf, Michael. All rights reserved.
//

import UIKit
import Foundation

private let reuseIdentifier = "Cell"

class CollectionViewController: UICollectionViewController {

    var theUpdatableObject:UpdateAvatar!
    var theSelectedGender:Int!
    
    let theMaleIconList = ["1.png","3.png","8.png","9.png","10.png","13.png"]
    let theFemaleIconList = ["2.png","4.png","5.png","6.png","7.png","11.png","12.png","14.png","15.png","16.png","17.png","18.png"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Register cell classes
        // self.collectionView!.register(UICollectionViewCell.self, forCellWithReuseIdentifier: reuseIdentifier)

        // Do any additional setup after loading the view.
        self.collectionView!.contentInset = UIEdgeInsets(top: 20, left: 0, bottom: 0, right: 0)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // Set, Update the UpdatableObject Avatar
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if self.theSelectedGender == 0 {
            self.theUpdatableObject.UpdateAvatar(theImageName: self.theMaleIconList[indexPath.row])
        } else {
            self.theUpdatableObject.UpdateAvatar(theImageName: self.theFemaleIconList[indexPath.row])
        }
        dismiss(animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */

    // MARK: UICollectionViewDataSource

    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    // Return number of items
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {

        if self.theSelectedGender == 0 {
            return self.theMaleIconList.count
        } else {
            return self.theFemaleIconList.count
        }
    }

    // Display Male or Female Icon List
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! CollectionViewCell

        if self.theSelectedGender == 0 {
            cell.theAvatar.image = UIImage(named: self.theMaleIconList[indexPath.row])
        } else {
            cell.theAvatar.image = UIImage(named: self.theFemaleIconList[indexPath.row])
        }
        return cell
    }

    // MARK: UICollectionViewDelegate

    /*
    // Uncomment this method to specify if the specified item should be highlighted during tracking
    override func collectionView(_ collectionView: UICollectionView, shouldHighlightItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment this method to specify if the specified item should be selected
    override func collectionView(_ collectionView: UICollectionView, shouldSelectItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
    override func collectionView(_ collectionView: UICollectionView, shouldShowMenuForItemAt indexPath: IndexPath) -> Bool {
        return false
    }

    override func collectionView(_ collectionView: UICollectionView, canPerformAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) -> Bool {
        return false
    }

    override func collectionView(_ collectionView: UICollectionView, performAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) {
    
    }
    */

}
