//
//  PhoneType.swift
//  Assignment1
//
//  Created by Assaf, Michael on 2017-02-07.
//  Copyright © 2017 Assaf, Michael. All rights reserved.
//

import Foundation

enum PhoneType:String {
    case Home = "Home"
    case Work = "Work"
    case Mobile = "Mobile"
    case Fax = "Fax"
}
