//
//  ContactSavable.swift
//  Assignment1
//
//  Created by Dirty Landlubber on 2017-02-09.
//  Copyright © 2017 Assaf, Michael. All rights reserved.
//

import Foundation

protocol ContactSavable {
    func SaveAContact(theContact:Contact, indexOfContact:Int!)
}
