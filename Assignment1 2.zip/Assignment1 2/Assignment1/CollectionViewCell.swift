//
//  CollectionViewCell.swift
//  Assignment1
//
//  Created by Dirty Landlubber on 2017-02-16.
//  Copyright © 2017 Assaf, Michael. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet var theAvatar: UIImageView!
}
