//
//  UpdateAvatar.swift
//  Assignment1
//
//  Created by Assaf, Michael on 2017-02-17.
//  Copyright © 2017 Assaf, Michael. All rights reserved.
//

import Foundation

protocol UpdateAvatar {
    func UpdateAvatar(theImageName: String)
}
