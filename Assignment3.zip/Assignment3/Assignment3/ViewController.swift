//
//  ViewController.swift
//  Assignment3
//
//  Created by Assaf, Michael on 2017-02-28.
//  Copyright © 2017 Assaf, Michael. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var theResults: UITextField!
    
    let myBrain = Brain()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

// Actions
extension ViewController {
    
    // CLEAR
    @IBAction func clearTap(_ sender: UIButton) {
        self.myBrain.clearBrain()
        self.theResults.text = self.myBrain.resultToString
    }
    
    // NUMBER PAD
    @IBAction func numberPadTap(_ sender: UIButton) {
        let number = sender.tag
        let currentResult = Int(self.myBrain.result)
        let result = Double("\(currentResult)\(number)")!
        
        self.myBrain.setCurrentResult(aResult: result)
        self.theResults.text = self.myBrain.resultToString
    }
    
    // OPERATIONS
    @IBAction func operationTap(_ sender: UIButton) {
        let operation = sender.restorationIdentifier
        self.myBrain.performOperation(symbol: operation!)
        self.theResults.text = "\(self.myBrain.resultToString) "+operation!+" ..."
    }
}

