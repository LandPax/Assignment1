//
//  Account.swift
//  Assignment5
//
//  Created by Assaf, Michael on 2017-04-21.
//  Copyright © 2017 Assaf, Michael. All rights reserved.
//

import Foundation

struct Account {
    let username:String
    let email:String
    let password:String
}
