//
//  ViewController.swift
//  Assignment5
//
//  Created by Assaf, Michael on 2017-04-21.
//  Copyright © 2017 Assaf, Michael. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var password: UITextField!
    
    let baseUrl = "http://104.196.10.107:9506"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func login(_ sender: UIButton) {
        
        let missingFields = fieldValidation(username: self.username.text!, password: self.password.text!)
        
        if missingFields != "" {
            let errorAlert = UIAlertController(title: "Error ", message: "Do not leave the following field(s) blank: " + missingFields, preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
            
            errorAlert.addAction(okAction)
            present(errorAlert, animated: true, completion: nil)
        }
    
        
        let urlCall = URL(string: baseUrl+"/json/username/"+self.username.text!)
        API.getAllData(theURL: urlCall!, onCompletion:{
            if account == nil {
                let errorAlert = UIAlertController(title: "Error ", message: "Account does not exist" + missingFields, preferredStyle: .alert)
                let okAction = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
            
                errorAlert.addAction(okAction)
                present(errorAlert, animated: true, completion: nil)
            }
        }
    }
    

    func fieldValidation(username:String, password:String) -> String {
        var missingFields = ""
        if self.username.text == "" {
            missingFields += " username"
        }
        if self.password.text == "" {
            missingFields += " password"
        }
        
        return missingFields
    }
}


APIInteractions.getAllData(theURL: APIDetails.buildUrl(callType: .allProducts, params: []) { (theProducts: [Product]?) -> () in
                            self.theProducts = theProducts!
                            DispatchQueue.main.async(){ () -> Void in
                                self.tableView.reloadData()
                            }
}

